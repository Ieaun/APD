﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test_Libary
{
    interface ITest
    {
        void Simple_ConsoleWrite(string Args);

    }
}
